#1. Import the dataset (‘Exercise.csv‘) into R and store it in a data frame called “student data”

setwd("C:/Users/Akash/Desktop/Lab 03")
data<-read.csv("Exercise.csv")
student_data <- read.csv("Exercise.csv")

#2. Produce the summary statistics and histogram for the variable “X1” (Age).

summary(student_data$X1)
hist(student_data$X1,
     main = "Histogram of Age",
     xlab = "Age",
     col = "skyblue",
     border = "white")

#3. Create a bar chart and frequency table for “X2” (Gender).

table(student_data$X2)

barplot(table(student_data$X2),
        main = "Gender Distribution",
        xlab = "Gender",
        ylab = "Frequency",
        col = c("lightcoral", "lightblue"),
        border = "white")

#4. How does the age (X1) change according to the accommodation (X3)? Analyze it
#using a suitable graph and interpret the results. (Note that accommodation has
#three levels which are type 1, type 2 and type 3)

boxplot(X1~X3,
        data = student_data,
        main = "Age Distribution by Accommodation Type",
        xlab = "Accommodation Type",
        ylab = "Age",
        col = c("lightgreen", "lightblue", "lightpink"),
        border = "gray")
